﻿using NttApi.Services;
using System;
using System.Linq;
using System.Web.Http;

namespace NttApi.Controllers
{
    public class ClaimsController : ApiController
    {
        //Note: Not Implementing OData, DI, Authentication and Exception handling

        private IClaimService _claimService;
        [HttpGet, Route("api/GetClaims/{dtClaimDate}")]
        public IHttpActionResult GetMemberClaims(DateTime dtClaimDate)
        {
            try
            {
                //DateTime dtClaimDate = DateTime.Now;
                _claimService = new ClaimsService();
                var p = _claimService.GetMemberClaims(dtClaimDate);
                if (p.Any())
                    return Ok(p);
                else
                    return Ok("Didn't find any members with claims upto the requested date.");
            }
            catch (Exception ex)
            {
                return InternalServerError(ex);//We don't show the underline error to the client but returing for simplicity.
            }

        }
    }
}
