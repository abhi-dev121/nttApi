﻿using Newtonsoft.Json;
using System;

namespace NttApi.Models
{
    public class ClaimsModel
    {
        [JsonIgnore]//Ignoring the property when sending out the JSON object
        public int MemberID { get; set; }
        public DateTime ClaimDate { get; set; }
        public decimal ClaimAmount { get; set; }

    }
}