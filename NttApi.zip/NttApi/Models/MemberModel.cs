using CsvHelper.Configuration.Attributes;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace NttApi.Models
{
    public class MemberModel
    {
        [JsonIgnore]//Ignoring the property when sending out the JSON object 
        public int MemberID { get; set; }
        [JsonIgnore]
        public DateTime EnrollmentDate { get; set; }
        [JsonIgnore]
        public string FirstName { get; set; }
        [JsonIgnore]
        public string LastName { get; set; }
        [Ignore]//CSVHelper attribute so the property doesn't have to match with the CSV column name
        public string MemberFullName { get; set; }
        [Ignore]
        public List<ClaimsModel> MemberClaims { get; set; }
    }
}