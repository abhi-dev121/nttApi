﻿using NttApi.Models;
using System;
using System.Collections.Generic;

namespace NttApi.Services
{
    public interface IClaimService
    {
        List<MemberModel> GetMemberClaims(DateTime dtClaimDate);
    }
}