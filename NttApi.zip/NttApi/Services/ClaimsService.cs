﻿using NttApi.Models;
using CsvHelper;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;

namespace NttApi.Services
{
    public class ClaimsService: IClaimService//We usually have separate project for Service layer
    {
        public List<MemberModel> GetMemberClaims(DateTime dtClaimDate)
        {
            //Using the Model objects for simplicity instead of creating the entity objects and then mapping
            List<MemberModel> members = LoadMembers().ToList();
            List<ClaimsModel> claims = LoadClaims().ToList();
            //claims.RemoveAll(k => k.ClaimDate < dtClaimDate);//remove the Claims received after the requested date
            foreach (MemberModel mm in members)
            {
                mm.MemberFullName = mm.FirstName + " " + mm.LastName;
                mm.MemberClaims = claims.FindAll(p => p.MemberID == mm.MemberID && p.ClaimDate.Date <= dtClaimDate.Date);
            }
            members.RemoveAll(k => k.MemberClaims.Count.Equals(0));//Remove members who doesn't have any claims

            return members;
        }
        // Place the Member.csv file in project folder and Load the data from it.
        private List<MemberModel> LoadMembers()
        {
            List<MemberModel> members = null;
            string filepath = AppDomain.CurrentDomain.BaseDirectory + "Member.csv";
            if (File.Exists(filepath))
            {
                //Using CSVHelper lib
                using (var reader = new StreamReader(filepath))
                using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
                {
                    // csv.Configuration.HeaderValidated = null;
                    members = csv.GetRecords<MemberModel>().ToList();
                }
            }
            return members;
        }

        // Place the Claims.csv file in project folder and Load the data from it.
        private List<ClaimsModel> LoadClaims()
        {
            List<ClaimsModel> claims = null;
            string filepath = AppDomain.CurrentDomain.BaseDirectory + "Claim.csv";
            if (File.Exists(filepath))
            {
                //Using CSVHelper lib
                using (var reader = new StreamReader(filepath))
                using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
                {
                    claims = csv.GetRecords<ClaimsModel>().ToList();
                }
            }
            return claims;
        }
    }
}